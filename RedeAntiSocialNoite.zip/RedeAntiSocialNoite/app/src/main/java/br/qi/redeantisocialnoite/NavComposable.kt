package br.qi.redeantisocialnoite

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import br.qi.redeantisocialnoite.screens.ScreenFeed
import br.qi.redeantisocialnoite.screens.ScreenLogin
import br.qi.redeantisocialnoite.screens.ScreenRegister

@Composable
fun MyNav(
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Rotas.Login,
        builder = {
            composable(Rotas.Login) { ScreenLogin(navController = navController) }
            composable(Rotas.Register) { ScreenRegister(navController = navController) }
            composable(Rotas.Feed) { ScreenFeed(navController = navController) }
        }
    )
}