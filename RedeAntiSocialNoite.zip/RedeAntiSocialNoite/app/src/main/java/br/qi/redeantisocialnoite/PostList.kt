package br.qi.redeantisocialnoite

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import br.qi.redeantisocialnoite.model.PostData
import br.qi.redeantisocialnoite.ui.theme.RedeAntiSocialNoiteTheme

@Composable
fun ListPost(
    list: List<PostData> = listagem,
    modifier: Modifier = Modifier
) {
    LazyColumn {
        items(list) {
            PostPage(
                imageUser = it.imageUser,
                nameUser = it.nameUser,
                timeUser = it.timeUser,
                imagePost = it.imagePost,
                textPost = it.textPost
            )
        }
    }
}

/////////////////////////////////////////////////////
@Preview(
    showBackground = true,
    heightDp = 400
)
@Composable
fun ListPostPreview() {
    RedeAntiSocialNoiteTheme {
        ListPost()
    }
}

//////////////////////////////////////////////////////////
val listagem = listOf<PostData>(
    PostData(
        imageUser = R.drawable.ic_launcher_foreground,
        nameUser = "Chaves",
        timeUser = "3 horas atrás",
        imagePost = R.drawable.ic_launcher_background,
        textPost = "Ninguém tem paciência comigo!"
    ),

    PostData(
        imageUser = R.drawable.ic_launcher_foreground,
        nameUser = "Kiko",
        timeUser = "2 horas atrás",
        imagePost = R.drawable.ic_launcher_background,
        textPost = "Gentalha, gentalha!"
    ),

    PostData(
        imageUser = R.drawable.ic_launcher_foreground,
        nameUser = "Chiquinha",
        timeUser = "1 horas atrás",
        imagePost = R.drawable.ic_launcher_background,
        textPost = "Sim...é, pois é, pois é!"
    ),

    PostData(
        imageUser = R.drawable.ic_launcher_foreground,
        nameUser = "Jaiminho",
        timeUser = "1 minuto atrás",
        imagePost = R.drawable.ic_launcher_background,
        textPost = "É que eu quero evitar a fadiga..."
    ),
)