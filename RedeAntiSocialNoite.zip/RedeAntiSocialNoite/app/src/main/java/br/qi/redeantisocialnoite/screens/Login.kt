package br.qi.redeantisocialnoite.screens

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.qi.redeantisocialnoite.LogoLogin
import br.qi.redeantisocialnoite.MyButton
import br.qi.redeantisocialnoite.MySwitchState
import br.qi.redeantisocialnoite.MyTextField
import br.qi.redeantisocialnoite.R
import br.qi.redeantisocialnoite.Rotas
import br.qi.redeantisocialnoite.ui.theme.RedeAntiSocialNoiteTheme

@Composable
fun ScreenLogin(
    navController: NavController,
    @DrawableRes logo: Int = R.drawable.ic_launcher_foreground,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LogoLogin(
            logo = logo
        )

        MyTextField(
            label = "Usuário",
            icon = Icons.Outlined.AccountCircle,
            isPassword = false
        )

        MyTextField(
            label = "Senha",
            icon = Icons.Outlined.Lock,
            isPassword = true
        )

        MySwitchState(
            text = "Mantenha-me conectado"
        )

        MyButton(
            label = "Entrar",
            size = 200.dp,
            action = { navController.navigate(Rotas.Feed) }
        )

        MyButton(
            label = "Registrar",
            size = 200.dp,
            action = { navController.navigate(Rotas.Register) }
        )
    }
}


/////////////////////////////////////////////////
@Preview(
    showBackground = true,
    widthDp = 320,
    heightDp = 620
)
@Composable
fun ScreenLoginPreview() {
    RedeAntiSocialNoiteTheme {
        //ScreenLogin()
    }
}