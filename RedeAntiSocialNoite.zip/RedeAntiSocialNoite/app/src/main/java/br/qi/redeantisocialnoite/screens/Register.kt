package br.qi.redeantisocialnoite.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.qi.redeantisocialnoite.DatePickerState
import br.qi.redeantisocialnoite.MyButton
import br.qi.redeantisocialnoite.MyTextField
import br.qi.redeantisocialnoite.ui.theme.RedeAntiSocialNoiteTheme

@Composable
fun ScreenRegister(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.SpaceAround,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Cadastro",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )

        MyTextField(
            label = "Nome",
            icon = Icons.Outlined.AccountCircle,
            isPassword = false
        )

        MyTextField(
            label = "Email",
            icon = Icons.Outlined.Email,
            isPassword = false
        )

        MyTextField(
            label = "Telefone",
            icon = Icons.Outlined.Phone,
            isPassword = false
        )

        DatePickerState()

        MyTextField(
            label = "Senha",
            icon = Icons.Outlined.Lock,
            isPassword = true
        )

        MyButton(
            label = "Cadastrar",
            size = 250.dp,
        )
    }
}

////////////////////////////////////////////////////////////////////////////
@Preview(
    showBackground = true,
    heightDp = 640,
    widthDp = 320
)
@Composable
fun ScreenRegisterPreview() {
    RedeAntiSocialNoiteTheme {
        //ScreenRegister()
    }
}