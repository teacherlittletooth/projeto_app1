package br.com.redeantisocialtarde.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DisplayMode
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.com.redeantisocialtarde.MyButton
import br.com.redeantisocialtarde.MyTextField
import br.com.redeantisocialtarde.ui.theme.RedeAntiSocialTardeTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


@Composable
fun RegisterScreen(
    navController: NavController,
    title: String = "Novo usuário",
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxSize()
    ) {
        var showModal by remember { mutableStateOf(false) }
        var showModalInput by remember { mutableStateOf(false) }
        var selectedDate by remember { mutableStateOf<Long?>(null) }

        Text(
            text = title
        )

        MyTextField(
            label = "Nome",
            isPassword = false,
            icon = Icons.Outlined.AccountCircle
        )

        MyTextField(
            label = "Email",
            isPassword = false,
            icon = Icons.Outlined.Email
        )

        MyTextField(
            label = "Telefone",
            isPassword = false,
            icon = Icons.Outlined.Phone
        )

        TextField(
            value = "",
            onValueChange = {}
        )

        TextField(
            value = "",
            onValueChange = {}
        )

        Button(onClick = { showModalInput = true }) {
            Text("Show Modal Input Date Picker")
        }

        if (selectedDate != null) {
            val date = Date(selectedDate!!)
            val formattedDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(date)
            Text("Selected date: $formattedDate")
        } else {
            Text("No date selected")
        }


        MyTextField(
            label = "Senha",
            isPassword = true,
            icon = Icons.Outlined.Lock
        )

        MyButton(
            label = "Cadastrar",
            size = 250.dp
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerModalInput(
    onDateSelected: (Long?) -> Unit,
    onDismiss: () -> Unit
) {
    val datePickerState = rememberDatePickerState(initialDisplayMode = DisplayMode.Input)

    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                onDateSelected(datePickerState.selectedDateMillis)
                onDismiss()
            }) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    ) {
        DatePicker(state = datePickerState)
    }
}

///////////////////////////////////////////////////////////////////////
@Preview(
    showBackground = true,
    heightDp = 680,
    widthDp = 340
)
@Composable
fun RegisterScreenPreview() {
    RedeAntiSocialTardeTheme {
        //RegisterScreen()
    }
}