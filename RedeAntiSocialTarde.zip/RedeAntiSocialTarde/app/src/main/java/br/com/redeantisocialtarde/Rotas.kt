package br.com.redeantisocialtarde

object Rotas {
    val AddPost  = "tela_add_post"
    val Feed     = "tela_feed"
    val Login    = "tela_login"
    val Profile  = "tela_profile"
    val Register = "tela_register"
}