package br.qi.socialmediatarde.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import br.qi.socialmediatarde.ListPost
import br.qi.socialmediatarde.MyBottomBar
import br.qi.socialmediatarde.MyTopBar
import br.qi.socialmediatarde.ui.theme.SocialMediaTardeTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    modifier: Modifier = Modifier
) {
    Scaffold(
        containerColor = Color(96, 143, 90, 159),
        topBar = { MyTopBar() },
        bottomBar = { MyBottomBar() }
    ) {
        Box(
            modifier = modifier.padding(it)
        ) {
            ListPost()
        }
    }
}

////////////////////////////////////////////////////
@Preview(showBackground = true)
@Composable
fun FeedScreenPreview() {
    SocialMediaTardeTheme {
        FeedScreen()
    }
}