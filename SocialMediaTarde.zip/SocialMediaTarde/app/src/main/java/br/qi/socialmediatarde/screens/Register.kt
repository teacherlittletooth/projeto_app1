package br.qi.socialmediatarde.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.qi.socialmediatarde.DatePickerState
import br.qi.socialmediatarde.MyButton
import br.qi.socialmediatarde.MyTextField
import br.qi.socialmediatarde.ui.theme.SocialMediaTardeTheme

@Composable
fun RegisterScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text(
            text = "Cadastro",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )

        MyTextField(
            label = "Nome",
            isPassword = false,
            icon = Icons.Outlined.AccountCircle
        )

        MyTextField(
            label = "Email",
            isPassword = false,
            icon = Icons.Outlined.Email
        )

        MyTextField(
            label = "Telefone",
            isPassword = false,
            icon = Icons.Outlined.Phone
        )

        DatePickerState()

        MyTextField(
            label = "Senha",
            isPassword = true,
            icon = Icons.Outlined.Lock
        )

        MyButton(
            label = "Cadastrar",
            size = 260.dp
        )
    }
}


////////////////////////////////////////////////////////////////
@Preview(
    showBackground = true,
    widthDp = 320,
    heightDp = 640
)
@Composable
fun RegisterScreenPreview() {
    SocialMediaTardeTheme {
        //RegisterScreen()
    }
}