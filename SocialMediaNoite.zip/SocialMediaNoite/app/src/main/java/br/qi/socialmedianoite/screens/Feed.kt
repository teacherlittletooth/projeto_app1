package br.qi.socialmedianoite.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import br.qi.socialmedianoite.ListPost
import br.qi.socialmedianoite.MyBottomBar
import br.qi.socialmedianoite.MyTopBar
import br.qi.socialmedianoite.ui.theme.SocialMediaNoiteTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = { MyTopBar() },
        bottomBar = { MyBottomBar() }
    ) {
        Box(
            modifier = modifier.padding(it)
        ) {
            ListPost()
        }
    }
}


//////////////////////////////////////////////////////
@Preview(showBackground = true)
@Composable
fun FeedScreenPreview() {
    SocialMediaNoiteTheme {
        FeedScreen()
    }
}