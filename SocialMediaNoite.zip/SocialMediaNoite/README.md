# "Rede Anti Social"
### Projeto realizado durante as aulas de Desenvolvimento de Aplicativos I do curso técnico de Informática para Internet da QI.

+ Arquivos de código fonte estão no seguinte local:
  - app/src/main/java/
 
+ Arquivo com as versões de dependências usadas pelo Gradle:
  - app/build.gradle.kts
