package br.qi.socialmediamanha.model

import br.qi.socialmediamanha.R

data class PostData(
    var profileImage: Int = R.drawable.ic_launcher_foreground,
    var profileName: String = "Nome do perfil",
    var timePost: String = "Agora",
    var imagePost: Int = R.drawable.ic_launcher_background,
    var textPost: String = "Texto da postagem"
)
