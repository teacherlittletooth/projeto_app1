package br.qi.socialmediamanha

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.AddCircle
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import br.qi.socialmediamanha.ui.theme.SocialMediaManhaTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTopBar(
    title: String = "Título",
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = {
            Text(text = title)
        },
        actions = {
            IconButton(
                onClick = {}
            ) {
                Icon(
                    imageVector = Icons.Outlined.MoreVert,
                    contentDescription = "Ícone de menu"
                )
            }//IconButton
        }
    )
}


@Composable
fun MyBottomBar(
    cor: Color = Color.DarkGray,
    corSelec: Color = Color.Blue,
    tamanho: Dp = 28.dp,
    tamanhoSelec: Dp = 40.dp,
    modifier: Modifier = Modifier
) {
    var itemSelec by remember {
        mutableStateOf(0)
    }

    BottomAppBar {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            modifier = modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { itemSelec = 0 }
            ) {
                Icon(
                    imageVector = Icons.Outlined.AccountCircle,
                    contentDescription = "Ícone de perfil",
                    tint = if(itemSelec == 0) corSelec else cor,
                    modifier = modifier
                        .size( if(itemSelec == 0) tamanhoSelec else tamanho )
                )
            }//IconButton

            IconButton(
                onClick = { itemSelec = 1 }
            ) {
                Icon(
                    imageVector = Icons.Outlined.AddCircle,
                    contentDescription = "Ícone de novo post",
                    tint = if(itemSelec == 1) corSelec else cor,
                    modifier = modifier
                        .size( if(itemSelec == 1) tamanhoSelec else tamanho )
                )
            }//IconButton

            IconButton(
                onClick = { itemSelec = 2 }
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Ícone de configurações",
                    tint = if(itemSelec == 2) corSelec else cor,
                    modifier = modifier
                        .size( if(itemSelec == 2) tamanhoSelec else tamanho )
                )
            }//IconButton
        }//Row
    }//BottomAppBar
}

////////////////////////////////////////////////////////////////
@Preview(showBackground = true)
@Composable
fun MyTopBarPreview() {
    SocialMediaManhaTheme {
        MyTopBar()
    }
}

@Preview(showBackground = true)
@Composable
fun MyBottomBarPreview() {
    SocialMediaManhaTheme {
        MyBottomBar()
    }
}