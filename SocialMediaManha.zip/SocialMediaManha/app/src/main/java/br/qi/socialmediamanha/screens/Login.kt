package br.qi.socialmediamanha.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.qi.socialmediamanha.LogoLogin
import br.qi.socialmediamanha.MyButton
import br.qi.socialmediamanha.MySwitchState
import br.qi.socialmediamanha.MyTextField
import br.qi.socialmediamanha.R
import br.qi.socialmediamanha.Rotas
import br.qi.socialmediamanha.ui.theme.SocialMediaManhaTheme

@Composable
fun LoginScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LogoLogin(
            logo = R.drawable.ic_launcher_foreground
        )

        MyTextField(
            label = "Usuário",
            isPassword = false,
            icon = Icons.Outlined.AccountCircle
        )

        MyTextField(
            label = "Senha",
            isPassword = true,
            icon = Icons.Outlined.Lock
        )

        MySwitchState(
            label = "Mantenha-me conectado"
        )

        MyButton(
            label = "Entrar",
            size = 300.dp,
            action = { navController.navigate(Rotas.Feed) }
        )

        MyButton(
            label = "Registrar",
            size = 300.dp,
            action = { navController.navigate(Rotas.Register) }
        )

    }//Column
}

////////////////////////////////////////////////
@Preview(
    showBackground = true,
    widthDp = 320,
    heightDp = 620
)
@Composable
fun LoginScreenPreview() {
    SocialMediaManhaTheme {
        //LoginScreen()
    }
}