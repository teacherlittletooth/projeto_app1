package br.qi.socialmediamanha

object Rotas {
    val Login     = "screen_login"
    val Register  = "screen_register"
    val Feed      = "screen_feed"
    val AddPost   = "screen_add_post"
    val Profile   = "screen_profile"
}