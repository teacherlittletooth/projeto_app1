package br.qi.socialmediamanha.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import br.qi.socialmediamanha.ListPost
import br.qi.socialmediamanha.MyBottomBar
import br.qi.socialmediamanha.MyTopBar
import br.qi.socialmediamanha.ui.theme.SocialMediaManhaTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = { MyTopBar() },
        bottomBar = { MyBottomBar() }
    ) {
        Box(
            modifier = modifier.padding(it)
        ) {
            ListPost()
        }
    }
}

//////////////////////////////////////////////////
@Preview(showBackground = true)
@Composable
fun FeedScreenPreview() {
    SocialMediaManhaTheme {
        //FeedScreen()
    }
}